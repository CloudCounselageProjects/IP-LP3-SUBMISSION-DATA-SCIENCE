# -*- coding: utf-8 -*-
"""
Created on Sun May  3 19:39:05 2020

@author: Vatsal Mehta
"""

import numpy as np
import pandas as pd


df=pd.read_csv('news.csv')

#dataset ko thoda analyze karre h

if True in df.isnull():
    print("Missing values exist in dataset\n")
else:
    print("\nNo missing values anywhere in dataset\n")    

print("\nData type of all columns is as follows:\n",df.dtypes)
print("\nNumber of rows and columns  are:\n",df.shape)
print("\nNames of columns are:\n",df.columns)


#kam ka input sirf text column me hai and output label column me
#kam ke input output dono ek ek hi hai isliye X and y me  alag store nai karvauga iloc use karke

from sklearn.model_selection import train_test_split

X=df.text
y=df.label

x_train,x_test,y_train,y_test=train_test_split(X, y, test_size=0.3, random_state=0)


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

tfidf_vectorizer=TfidfVectorizer(stop_words='english', max_df=0.7)

# Fit and transform train set
tfidf_train=tfidf_vectorizer.fit_transform(x_train) 
tfidf_test=tfidf_vectorizer.transform(x_test)

tfidf_vectorizer=TfidfVectorizer(stop_words='english', max_df=0.7)
tfidf_train=tfidf_vectorizer.fit_transform(x_train) 
tfidf_test=tfidf_vectorizer.transform(x_test)

pac=PassiveAggressiveClassifier(max_iter=50)
pac.fit(tfidf_train,y_train)


y_pred=pac.predict(tfidf_test)
score=(accuracy_score(y_test,y_pred))*100

score.astype
print('Accuracy: ',score)

#confusion_matrix(y_test,y_pred, labels=['FAKE','REAL'])
y_pred=np.array(y_pred)
y_test=np.array(y_test)

#for 10 values

print("predicted values   Actual values")
for i in range(0,10):
      print(y_pred[i],"               ",y_test[i])

   