#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import itertools
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, HashingVectorizer
from sklearn.model_selection import train_test_split 
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics
import matplotlib.pyplot as plt


# In[2]:


get_ipython().run_line_magic('pylab', 'inline')


# In[3]:


df = pd.read_csv('news.csv')


# In[4]:


df.head()


# In[5]:


dfreal = df.loc[:,:'label']


# In[6]:


dfreal.head()


# In[7]:


dfreal.set_index('Unnamed: 0')


# In[8]:


dfreal.shape


# In[9]:


y = dfreal.label


# In[10]:


df = dfreal.set_index('Unnamed: 0')


# In[11]:


df = df.drop(['label'], axis=1)


# In[12]:


df['text'].fillna('no text', inplace=True)


# In[13]:


X_train, X_test, y_train, y_test = train_test_split(df['text'], y, test_size = 0.2, random_state= 53)


# In[14]:


count_vectorizer = CountVectorizer(stop_words='english')
count_train = count_vectorizer.fit_transform(X_train.astype(str))
count_test = count_vectorizer.transform(X_test.astype(str))


# In[15]:


tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_df=0.7)
tfidf_train = tfidf_vectorizer.fit_transform(X_train.astype(str))
tfidf_test = tfidf_vectorizer.transform(X_test.astype(str))


# In[16]:


tfidf_vectorizer.get_feature_names()[-10:]


# In[17]:


count_vectorizer.get_feature_names()[:10]


# In[18]:


count_df = pd.DataFrame(count_train.A, columns=count_vectorizer.get_feature_names())


# In[19]:


tfidf_df = pd.DataFrame(tfidf_train.A, columns=tfidf_vectorizer.get_feature_names())


# In[ ]:


difference = set(count_df.columns) - set(tfidf_df.columns)
difference


# In[ ]:


print(count_df.equals(tfidf_df))


# In[ ]:





# In[ ]:


count_df.head()


# In[ ]:


tfidf_df.head()


# In[ ]:


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    See full source and example: 
    http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html
    
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, cm[i, j],
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# In[ ]:


clf = MultinomialNB()


# In[ ]:


y_train.fillna('FAKE',inplace=True)


# In[ ]:


y_test.fillna('FAKE',inplace=True)


# In[ ]:


clf.fit(tfidf_train, y_train)
pred = clf.predict(tfidf_test)
score = metrics.accuracy_score(y_test, pred)
print("accuracy:   %0.3f" % score)
cm = metrics.confusion_matrix(y_test, pred, labels=['FAKE', 'REAL'])
plot_confusion_matrix(cm, classes=['FAKE', 'REAL'])


# In[ ]:


clf = MultinomialNB()


# In[ ]:


clf.fit(count_train, y_train)
pred = clf.predict(count_test)
score = metrics.accuracy_score(y_test, pred)
print("accuracy:   %0.3f" % score)
cm = metrics.confusion_matrix(y_test, pred, labels=['FAKE', 'REAL'])
plot_confusion_matrix(cm, classes=['FAKE', 'REAL'])


# In[ ]:




