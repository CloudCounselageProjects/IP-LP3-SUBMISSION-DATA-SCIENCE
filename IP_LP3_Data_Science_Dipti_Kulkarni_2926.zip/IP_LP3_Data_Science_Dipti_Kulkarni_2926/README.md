# fake_news_detection
<br>Here's a python code using sklearn, tfidf and a confusion matrix to detect fake news<br>
<br>A PassiveAggressiveClassifier is initialized to fit the model<br>
<br>Then the accuracy score and the confusion matrix are used to tell how well the model fares<br>