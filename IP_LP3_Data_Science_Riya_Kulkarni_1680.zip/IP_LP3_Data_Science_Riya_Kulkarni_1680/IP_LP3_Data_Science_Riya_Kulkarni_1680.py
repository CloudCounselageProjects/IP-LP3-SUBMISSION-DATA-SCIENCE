#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import itertools
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, HashingVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics
import matplotlib.pyplot as plt


# In[2]:


get_ipython().run_line_magic('pylab', 'inline')


# In[3]:


df = pd.read_csv('news.csv')


# In[4]:


df.shape


# In[5]:


df.head()


# In[6]:


df = df.set_index('Unnamed: 0')


# In[7]:


df.head()


# In[8]:


y = df.label


# In[9]:


df = df.drop('label', axis=1)


# In[10]:


X_train, X_test, y_train, y_test = train_test_split(df['text'], y, test_size=0.33, random_state=53)


# In[11]:


count_vectorizer = CountVectorizer(stop_words='english')
count_train = count_vectorizer.fit_transform(X_train)
count_test = count_vectorizer.transform(X_test)


# In[12]:


tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_df=0.7)
tfidf_train = tfidf_vectorizer.fit_transform(X_train)
tfidf_test = tfidf_vectorizer.transform(X_test)


# In[13]:


tfidf_vectorizer.get_feature_names()[-10:]


# In[14]:


count_vectorizer.get_feature_names()[:10]


# In[15]:


count_df = pd.DataFrame(count_train.A, columns=count_vectorizer.get_feature_names())


# In[16]:


tfidf_df = pd.DataFrame(tfidf_train.A, columns=tfidf_vectorizer.get_feature_names())


# In[17]:


difference = set(count_df.columns) - set(tfidf_df.columns)
difference


# In[18]:


print(count_df.equals(tfidf_df))


# In[19]:


count_df.head()


# In[20]:


tfidf_df.head()


# In[21]:


linear_clf = PassiveAggressiveClassifier()


# In[28]:


from sklearn.metrics import plot_confusion_matrix 
linear_clf.fit(tfidf_train, y_train)
pred = linear_clf.predict(tfidf_test)
score = metrics.accuracy_score(y_test, pred)
print("accuracy:   %0.3f" % score)


# In[29]:


clf = MultinomialNB(alpha=0.1)


# In[30]:


last_score = 0
for alpha in np.arange(0,1,.1):
    nb_classifier = MultinomialNB(alpha=alpha)
    nb_classifier.fit(tfidf_train, y_train)
    pred = nb_classifier.predict(tfidf_test)
    score = metrics.accuracy_score(y_test, pred)
    if score > last_score:
        clf = nb_classifier
    print("Alpha: {:.2f} Score: {:.5f}".format(alpha, score))


# In[31]:


def most_informative_feature_for_binary_classification(vectorizer, classifier, n=100):
    

    class_labels = classifier.classes_
    feature_names = vectorizer.get_feature_names()
    topn_class1 = sorted(zip(classifier.coef_[0], feature_names))[:n]
    topn_class2 = sorted(zip(classifier.coef_[0], feature_names))[-n:]

    for coef, feat in topn_class1:
        print(class_labels[0], coef, feat)

    print()

    for coef, feat in reversed(topn_class2):
        print(class_labels[1], coef, feat)


most_informative_feature_for_binary_classification(tfidf_vectorizer, linear_clf, n=30)


# In[ ]:




