import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import metrics


def classifier(tfidf_train,y_train,tfidf_test,y_test):
	clf=PassiveAggressiveClassifier(n_iter=50)

	clf.fit(tfidf_train,y_train)
	pred=clf.predict(tfidf_test)
	return pred

def accuracy_score(pred,y_test):
	score=metrics.accuracy_score(y_test,pred)
	accuracy=round(score,3)

	return accuracy

def main():
	df=pd.read_csv("news.csv")

	target=df['label']
	df.drop("label",axis=1)

	x_train,x_test,y_train,y_test=train_test_split(df['text'],target,test_size=0.25,random_state=50)
	
	tfidf_vectorizer=TfidfVectorizer(stop_words='english',max_df=0.7)
	tfidf_train=tfidf_vectorizer.fit_transform(x_train)
	tfidf_test=tfidf_vectorizer.transform(x_test)
	
	pred=classifier(tfidf_train,y_train,tfidf_test,y_test)
	score=accuracy_score(pred,y_test)
	
	print("accuracy:  %0.3f" %score)
	conf_matrix=metrics.confusion_matrix(y_test,pred,labels=['FAKE','REAL'])
	print("Confusion Matrix: ")
	print(conf_matrix)

main()




