LP3_Project consist of :
1) news.csv - Data Set.
2) Fake_News_Detection.ipynb
3) Fake_News_Detection.py
4) Fake_News_Detection.pdf

The files from 2) to 4) are same just for the convenience, I have provided the same assignment in various 
extensions.


