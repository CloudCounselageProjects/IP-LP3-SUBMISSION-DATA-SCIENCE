
# coding: utf-8

# In[1]:


#IMPORT ALL NECESSARY LIBRARIES NEEDED FOR ASSIGNMENT
import pandas as pd
import itertools
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import confusion_matrix,accuracy_score

data=pd.read_csv("news.csv")# READ THE DATA
y=data.label
print(y)


# In[2]:


#DIVIDE DATA INTO TRAINING AND TEST SETS
x_train,x_test,y_train,y_test=train_test_split(data['text'], y, test_size=0.2, random_state=1)


# In[3]:


#CREATE A VECTORIZER
vector= TfidfVectorizer()
tfidf_train=vector.fit_transform(x_train) 
tfidf_test=vector.transform(x_test)


# In[4]:


#INITIALIZE PASSIVE AGGRESSIVE CLASSIFIER
rom=PassiveAggressiveClassifier(max_iter=50)
rom.fit(tfidf_train,y_train)


# In[5]:


#CALCULATE ACCURACY AND CONFUSION MATRIX
y_pred=rom.predict(tfidf_test)
accuracy=accuracy_score(y_test,y_pred)
print(f'Accuracy: {round(accuracy*100,2)}%')


# In[6]:


confusion_matrix(y_test,y_pred, labels=['FAKE','REAL'])

